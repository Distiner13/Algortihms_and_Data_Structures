//package comp352.dsandalgos.huffman;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;

/*Q2)What is the purpose of using a priority queue in Huffman coding, and how does it help to generate an optimal code?
	 Answer:
*/

/*Q3)How does the length of a Huffman code relate to the frequency of the corresponding symbol, and why is this useful for data compression?
	Answer:
*/

/*Q4)What is the time complexity of building a Huffman code, and how can you optimize it?
	Answer:  
*/

class HuffmanNode {
	int ch;
	int frequency;
	HuffmanNode left;
	HuffmanNode right;

	HuffmanNode(int ch, int frequency, HuffmanNode left, HuffmanNode right) {
		this.ch = ch;
		this.frequency = frequency;
		this.left = left;
		this.right = right;
	}

	// Time O(1) Space O(1)
	@Override
	public String toString() {
		return "(" + ch + ", " + frequency + ")";
	}

	public boolean compareTo(HuffmanNode node) {
		return (this.frequency > node.frequency);
	}
}

class OrderedList extends LinkedList<HuffmanNode> {
	private static final long serialVersionUID = 1L;

	public void orderedAdd(HuffmanNode element) {
		ListIterator<HuffmanNode> itr = listIterator();
		while (itr.hasNext()) {
			if (itr.next().compareTo(element)) {
				itr.previous();
				break;
			}
		}
		itr.add(element);
	}
}

public class HCDriver {

	public static void main(String[] args) {
		String fileName = args[0];
		Map<Integer, Integer> char_map = readFileContentAndBuildCharMap(fileName);
		System.out.print(char_map);

		buildHuffmanTree(char_map);
	}

	public static Map<Integer, Integer> readFileContentAndBuildCharMap(String fileName) {
		Map<Integer, Integer> character_map = new HashMap<Integer, Integer>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			int input = 0;
			while ((input = reader.read()) != -1) {
				character_map.put(input, character_map.getOrDefault(input, 0) + 1);
				// System.out.println(character_map);
			}
		} catch (Exception e) {
			System.out.println("exception caugth");
		}
		return character_map;
	}

	public static void buildHuffmanTree(Map<Integer, Integer> char_map) {
		OrderedList ordered_char_list = new OrderedList();
		for (var entry : char_map.entrySet()) {
			ordered_char_list.orderedAdd(new HuffmanNode(entry.getKey(), entry.getValue(), null, null));
		}
		// System.out.println(ordered_char_list);

		while (ordered_char_list.size() > 1) {
			HuffmanNode node1 = ordered_char_list.remove();
			HuffmanNode node2 = ordered_char_list.remove();
			HuffmanNode node = new HuffmanNode(0, node1.frequency + node2.frequency, node1, node2);
			ordered_char_list.orderedAdd(node);
		}
		System.out.println(ordered_char_list);
	}

}
